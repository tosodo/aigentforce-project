// main.js
// Shared JavaScript functionality

// Get CSRF token
function getCsrfToken() {
  return generateCsrfToken();
}

// Generate CSRF token (client-side - matches server-side logic)
function generateCsrfToken() {
  // This should match the PHP hash_hmac logic
  // For simplicity, we'll use a placeholder that the server validates
  return 'csrf_token_placeholder';
}

// Generic form submission handler
async function submitForm(endpoint, data) {
  try {
    // Add CSRF token
    data.csrf_token = getCsrfToken();

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data)
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.error || 'Submission failed');
    }

    return result;
  } catch (error) {
    console.error('Form submission error:', error);
    throw error;
  }
}

// Show success message
function showSuccess(message, containerId = 'form-message') {
  const container = document.getElementById(containerId);
  if (container) {
    container.innerHTML = `<div class="alert alert-success">${message}</div>`;
    container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
}

// Show error message
function showError(message, containerId = 'form-message') {
  const container = document.getElementById(containerId);
  if (container) {
    container.innerHTML = `<div class="alert alert-error">${message}</div>`;
    container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
}

// Validate email
function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

// Smooth scroll to element
function scrollToElement(elementId) {
  const element = document.getElementById(elementId);
  if (element) {
    element.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}
