// assessment.js
// AI Readiness Assessment logic

const assessmentData = {
  currentStep: 0,
  answers: {},
  pillars: [
    'Data readiness',
    'Process clarity',
    'People & roles',
    'Infrastructure & tooling',
    'Governance & risk'
  ],
  questions: [
    // Data readiness (4 questions)
    {
      pillar: 'Data readiness',
      id: 'data_q1',
      text: 'How structured and accessible is your operational data?',
      options: [
        { value: 0, label: 'Mostly paper-based or unstructured' },
        { value: 1, label: 'Some digital records, inconsistent format' },
        { value: 2, label: 'Digital but siloed across systems' },
        { value: 3, label: 'Centralized with some integration' },
        { value: 4, label: 'Fully integrated and queryable' }
      ]
    },
    {
      pillar: 'Data readiness',
      id: 'data_q2',
      text: 'How clean and reliable is your data?',
      options: [
        { value: 0, label: 'Frequent errors and duplicates' },
        { value: 1, label: 'Some quality issues' },
        { value: 2, label: 'Generally reliable with occasional gaps' },
        { value: 3, label: 'High quality with documented standards' },
        { value: 4, label: 'Validated, audited, and continuously monitored' }
      ]
    },
    {
      pillar: 'Data readiness',
      id: 'data_q3',
      text: 'Do you have clear data ownership and governance?',
      options: [
        { value: 0, label: 'No defined ownership' },
        { value: 1, label: 'Informal ownership' },
        { value: 2, label: 'Defined owners but limited governance' },
        { value: 3, label: 'Clear ownership with documented policies' },
        { value: 4, label: 'Comprehensive governance framework' }
      ]
    },
    {
      pillar: 'Data readiness',
      id: 'data_q4',
      text: 'Can you easily extract and analyze data for decision-making?',
      options: [
        { value: 0, label: 'Requires significant manual effort' },
        { value: 1, label: 'Basic reporting available' },
        { value: 2, label: 'Regular reports with some self-service' },
        { value: 3, label: 'Self-service analytics available' },
        { value: 4, label: 'Real-time dashboards and advanced analytics' }
      ]
    },

    // Process clarity (4 questions)
    {
      pillar: 'Process clarity',
      id: 'process_q1',
      text: 'How well-documented are your core operational processes?',
      options: [
        { value: 0, label: 'Undocumented, tribal knowledge' },
        { value: 1, label: 'Some informal documentation' },
        { value: 2, label: 'Key processes documented' },
        { value: 3, label: 'Comprehensive documentation maintained' },
        { value: 4, label: 'Fully mapped with continuous improvement' }
      ]
    },
    {
      pillar: 'Process clarity',
      id: 'process_q2',
      text: 'How standardized are your workflows across the organization?',
      options: [
        { value: 0, label: 'Highly variable by person/team' },
        { value: 1, label: 'Some common practices' },
        { value: 2, label: 'Standardized for core processes' },
        { value: 3, label: 'Consistent with defined exceptions' },
        { value: 4, label: 'Fully standardized and optimized' }
      ]
    },
    {
      pillar: 'Process clarity',
      id: 'process_q3',
      text: 'Do you measure process performance and outcomes?',
      options: [
        { value: 0, label: 'No formal measurement' },
        { value: 1, label: 'Ad-hoc tracking' },
        { value: 2, label: 'Key metrics tracked regularly' },
        { value: 3, label: 'Comprehensive KPIs with targets' },
        { value: 4, label: 'Real-time monitoring with continuous optimization' }
      ]
    },
    {
      pillar: 'Process clarity',
      id: 'process_q4',
      text: 'How quickly can you identify and resolve process bottlenecks?',
      options: [
        { value: 0, label: 'Reactive, after significant impact' },
        { value: 1, label: 'Identified through complaints' },
        { value: 2, label: 'Regular reviews identify issues' },
        { value: 3, label: 'Proactive monitoring and resolution' },
        { value: 4, label: 'Predictive analytics prevent bottlenecks' }
      ]
    },

    // People & roles (4 questions)
    {
      pillar: 'People & roles',
      id: 'people_q1',
      text: 'How comfortable is your team with digital tools and technology?',
      options: [
        { value: 0, label: 'Significant resistance to change' },
        { value: 1, label: 'Basic digital literacy' },
        { value: 2, label: 'Comfortable with standard tools' },
        { value: 3, label: 'Proactive adopters of new technology' },
        { value: 4, label: 'Digital-first mindset across organization' }
      ]
    },
    {
      pillar: 'People & roles',
      id: 'people_q2',
      text: 'Do you have clear roles and responsibilities for technology initiatives?',
      options: [
        { value: 0, label: 'No defined roles' },
        { value: 1, label: 'Ad-hoc assignments' },
        { value: 2, label: 'Key roles identified' },
        { value: 3, label: 'Clear ownership with accountability' },
        { value: 4, label: 'Dedicated team with executive sponsorship' }
      ]
    },
    {
      pillar: 'People & roles',
      id: 'people_q3',
      text: 'How do you approach training and upskilling?',
      options: [
        { value: 0, label: 'No formal training program' },
        { value: 1, label: 'Occasional external training' },
        { value: 2, label: 'Regular training for key staff' },
        { value: 3, label: 'Structured development programs' },
        { value: 4, label: 'Continuous learning culture with clear pathways' }
      ]
    },
    {
      pillar: 'People & roles',
      id: 'people_q4',
      text: 'How does leadership support technology and innovation?',
      options: [
        { value: 0, label: 'Limited awareness or interest' },
        { value: 1, label: 'Supportive but not actively involved' },
        { value: 2, label: 'Regular engagement and budget allocation' },
        { value: 3, label: 'Active champions with clear vision' },
        { value: 4, label: 'Innovation embedded in strategy and culture' }
      ]
    },

    // Infrastructure & tooling (4 questions)
    {
      pillar: 'Infrastructure & tooling',
      id: 'infra_q1',
      text: 'How modern and reliable is your IT infrastructure?',
      options: [
        { value: 0, label: 'Legacy systems, frequent issues' },
        { value: 1, label: 'Mix of old and new, some reliability concerns' },
        { value: 2, label: 'Generally modern with occasional issues' },
        { value: 3, label: 'Modern, cloud-based, reliable' },
        { value: 4, label: 'Cutting-edge, highly available, scalable' }
      ]
    },
    {
      pillar: 'Infrastructure & tooling',
      id: 'infra_q2',
      text: 'How well do your systems integrate with each other?',
      options: [
        { value: 0, label: 'Completely siloed' },
        { value: 1, label: 'Manual data transfer between systems' },
        { value: 2, label: 'Some automated integrations' },
        { value: 3, label: 'Well-integrated core systems' },
        { value: 4, label: 'Fully integrated with API-first architecture' }
      ]
    },
    {
      pillar: 'Infrastructure & tooling',
      id: 'infra_q3',
      text: 'Do you have the technical capability to implement AI solutions?',
      options: [
        { value: 0, label: 'No technical resources' },
        { value: 1, label: 'Basic IT support only' },
        { value: 2, label: 'Some technical capability, external help needed' },
        { value: 3, label: 'Strong internal team with AI awareness' },
        { value: 4, label: 'Dedicated AI/ML capability' }
      ]
    },
    {
      pillar: 'Infrastructure & tooling',
      id: 'infra_q4',
      text: 'How do you approach technology vendor selection and management?',
      options: [
        { value: 0, label: 'Ad-hoc, no formal process' },
        { value: 1, label: 'Basic evaluation criteria' },
        { value: 2, label: 'Structured selection process' },
        { value: 3, label: 'Comprehensive evaluation with ongoing management' },
        { value: 4, label: 'Strategic partnerships with continuous optimization' }
      ]
    },

    // Governance & risk (4 questions)
    {
      pillar: 'Governance & risk',
      id: 'governance_q1',
      text: 'How do you manage data privacy and security?',
      options: [
        { value: 0, label: 'No formal policies' },
        { value: 1, label: 'Basic security measures' },
        { value: 2, label: 'Documented policies, regular reviews' },
        { value: 3, label: 'Comprehensive framework with training' },
        { value: 4, label: 'Industry-leading practices with continuous monitoring' }
      ]
    },
    {
      pillar: 'Governance & risk',
      id: 'governance_q2',
      text: 'Do you have a process for assessing technology risks?',
      options: [
        { value: 0, label: 'No formal risk assessment' },
        { value: 1, label: 'Ad-hoc risk consideration' },
        { value: 2, label: 'Risk assessment for major initiatives' },
        { value: 3, label: 'Structured risk framework' },
        { value: 4, label: 'Comprehensive risk management with mitigation plans' }
      ]
    },
    {
      pillar: 'Governance & risk',
      id: 'governance_q3',
      text: 'How do you ensure compliance with relevant regulations?',
      options: [
        { value: 0, label: 'Limited awareness' },
        { value: 1, label: 'Basic compliance efforts' },
        { value: 2, label: 'Regular compliance reviews' },
        { value: 3, label: 'Proactive compliance program' },
        { value: 4, label: 'Embedded compliance with continuous monitoring' }
      ]
    },
    {
      pillar: 'Governance & risk',
      id: 'governance_q4',
      text: 'Do you have ethical guidelines for AI and automation use?',
      options: [
        { value: 0, label: 'Not considered' },
        { value: 1, label: 'Informal discussions' },
        { value: 2, label: 'Basic principles documented' },
        { value: 3, label: 'Clear ethical framework' },
        { value: 4, label: 'Comprehensive ethics program with oversight' }
      ]
    }
  ]
};

// Calculate scores
function calculateScores() {
  const pillarScores = {};
  let totalScore = 0;

  // Initialize pillar scores
  assessmentData.pillars.forEach(pillar => {
    pillarScores[pillar] = 0;
  });

  // Sum scores by pillar
  assessmentData.questions.forEach(question => {
    const answer = assessmentData.answers[question.id];
    if (answer !== undefined) {
      pillarScores[question.pillar] += answer;
      totalScore += answer;
    }
  });

  return { pillarScores, totalScore };
}

// Generate recommendations based on score
function generateRecommendations(totalScore, pillarScores) {
  const recommendations = [];
  let riskLevel = 'low';
  let suggestedCta = '';

  if (totalScore < 40) {
    riskLevel = 'high';
    recommendations.push(
      'Start with a focused discovery workshop to identify 1–2 high-impact, low-risk AI use cases.',
      'Invest in foundational data and process documentation before scaling AI initiatives.',
      'Build internal awareness through executive briefings and targeted training for key stakeholders.'
    );
    suggestedCta = 'Book a discovery call to map a pragmatic AI readiness roadmap tailored to your current state.';
  } else if (totalScore < 70) {
    riskLevel = 'medium';
    recommendations.push(
      'Select 1–2 cross-functional workflows where AI can remove manual work without disrupting core systems.',
      'Run a structured pilot that pairs operations leaders with an AI implementation partner.',
      'Formalise measurement: define a small set of operational and risk metrics per pilot.'
    );
    suggestedCta = 'Use the workshop to shape a pilot automation programme that can be extended across functions.';
  } else {
    riskLevel = 'low';
    recommendations.push(
      'Scale proven AI use cases across departments with clear ROI tracking.',
      'Establish a centre of excellence to govern AI deployment, ethics, and continuous improvement.',
      'Explore advanced capabilities: predictive analytics, intelligent process automation, or custom ML models.'
    );
    suggestedCta = 'Engage with our team to design an enterprise AI transformation programme.';
  }

  // Add pillar-specific recommendations
  Object.entries(pillarScores).forEach(([pillar, score]) => {
    if (score < 8) {
      recommendations.push(`Priority: Strengthen ${pillar.toLowerCase()} through targeted initiatives.`);
    }
  });

  return { recommendations, riskLevel, suggestedCta };
}

// Initialize assessment
function initAssessment() {
  renderQuestion();
  updateProgress();
}

// Render current question
function renderQuestion() {
  const question = assessmentData.questions[assessmentData.currentStep];
  const container = document.getElementById('question-container');

  if (!container) return;

  let html = `
    <div class="question-card">
      <h3 class="mb-md">${question.pillar}</h3>
      <p class="mb-lg"><strong>${question.text}</strong></p>
      <div class="radio-group">
  `;

  question.options.forEach(option => {
    const checked = assessmentData.answers[question.id] === option.value ? 'checked' : '';
    html += `
      <label class="radio-option">
        <input type="radio" name="${question.id}" value="${option.value}" ${checked} 
               onchange="selectAnswer('${question.id}', ${option.value})">
        <span>${option.label}</span>
      </label>
    `;
  });

  html += `
      </div>
    </div>
  `;

  container.innerHTML = html;

  // Update navigation buttons
  updateNavigation();
}

// Select answer
function selectAnswer(questionId, value) {
  assessmentData.answers[questionId] = value;
  updateProgress();
}

// Update progress bar
function updateProgress() {
  const progress = (Object.keys(assessmentData.answers).length / assessmentData.questions.length) * 100;
  const progressBar = document.getElementById('progress-bar');
  if (progressBar) {
    progressBar.style.width = progress + '%';
  }
}

// Update navigation
function updateNavigation() {
  const prevBtn = document.getElementById('prev-btn');
  const nextBtn = document.getElementById('next-btn');
  const submitBtn = document.getElementById('submit-btn');

  if (prevBtn) {
    prevBtn.style.display = assessmentData.currentStep > 0 ? 'inline-block' : 'none';
  }

  const isLastQuestion = assessmentData.currentStep === assessmentData.questions.length - 1;
  const currentAnswer = assessmentData.answers[assessmentData.questions[assessmentData.currentStep].id];

  if (nextBtn) {
    nextBtn.style.display = !isLastQuestion ? 'inline-block' : 'none';
    nextBtn.disabled = currentAnswer === undefined;
  }

  if (submitBtn) {
    submitBtn.style.display = isLastQuestion ? 'inline-block' : 'none';
    submitBtn.disabled = currentAnswer === undefined;
  }
}

// Next question
function nextQuestion() {
  if (assessmentData.currentStep < assessmentData.questions.length - 1) {
    assessmentData.currentStep++;
    renderQuestion();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}

// Previous question
function prevQuestion() {
  if (assessmentData.currentStep > 0) {
    assessmentData.currentStep--;
    renderQuestion();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}

// Submit assessment
async function submitAssessment() {
  const { pillarScores, totalScore } = calculateScores();
  const { recommendations, riskLevel, suggestedCta } = generateRecommendations(totalScore, pillarScores);

  // Get lead info
  const name = document.getElementById('lead-name')?.value || '';
  const email = document.getElementById('lead-email')?.value || '';
  const company = document.getElementById('lead-company')?.value || '';
  const role = document.getElementById('lead-role')?.value || '';
  const teamSize = document.getElementById('lead-team-size')?.value || '';

  if (!email || !validateEmail(email)) {
    showError('Please provide a valid email address');
    return;
  }

  // Prepare payload
  const payload = {
    name,
    email,
    company,
    role,
    team_size: teamSize,
    assessment: {
      answers: assessmentData.answers,
      total_score: totalScore,
      pillar_scores: pillarScores,
      risk_level: riskLevel,
      recommendations,
      suggested_cta: suggestedCta
    }
  };

  try {
    // Submit to API
    await submitForm('/api/assessment.php', payload);

    // Store results for results page
    sessionStorage.setItem('assessmentResults', JSON.stringify(payload.assessment));
    sessionStorage.setItem('assessmentLead', JSON.stringify({ name, email, company }));

    // Redirect to results page
    window.location.href = '/assessment/results.html';
  } catch (error) {
    showError('Failed to submit assessment. Please try again.');
  }
}
