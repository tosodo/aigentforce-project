<?php
// index.php - Home page
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AiGentForce.io - Executive AI Strategy, Training & Automation</title>
    <meta name="description" content="Systems-first AI training and automation for SMEs, local service businesses, and agencies. No hype. Just practical implementation.">
    <link rel="stylesheet" href="/assets/css/styles.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="/" class="logo">AiGentForce.io</a>
                <nav class="nav">
                    <a href="/workshops/">Workshops</a>
                    <a href="/assessment/">AI Readiness</a>
                    <a href="/resources/">Resources</a>
                    <a href="/book/">Book Call</a>
                </nav>
            </div>
        </div>
    </header>

    <!-- Hero -->
    <section class="hero">
        <div class="container">
            <h1>Executive AI Strategy, Training & Automation</h1>
            <p>Systems-first AI implementation for SMEs and service businesses. No hype. Just practical, measurable outcomes.</p>
            <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                <a href="/workshops/" class="btn btn-primary btn-lg">View Workshops</a>
                <a href="/assessment/" class="btn btn-secondary btn-lg">AI Readiness Scorecard</a>
            </div>
        </div>
    </section>

    <!-- Value Proposition -->
    <section class="section">
        <div class="container">
            <h2 class="text-center mb-xl">What We Do</h2>
            <div class="grid grid-3">
                <div class="card">
                    <h3 class="card-title">AI Training & Workshops</h3>
                    <p class="card-text">Focused, practical training for leadership teams and operators. Public sessions, team passes, and private workshops tailored to your workflows.</p>
                    <a href="/workshops/" class="btn btn-primary">View Options</a>
                </div>
                <div class="card">
                    <h3 class="card-title">AI Readiness Assessment</h3>
                    <p class="card-text">Benchmark your organisation across data, process, people, infrastructure, and governance. Get clear, actionable next steps in under 10 minutes.</p>
                    <a href="/assessment/" class="btn btn-primary">Take Assessment</a>
                </div>
                <div class="card">
                    <h3 class="card-title">Automation Implementation</h3>
                    <p class="card-text">Design and deploy AI-driven workflows for lead handling, document processing, customer support, and operations.</p>
                    <a href="/book/" class="btn btn-primary">Book Discovery Call</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Proof -->
    <section class="section" style="background: var(--soft-grey);">
        <div class="container">
            <h2 class="text-center mb-xl">Representative Implementations</h2>
            <div class="grid grid-2">
                <div class="card">
                    <h4>Nestead Properties</h4>
                    <p>Real-estate operations workflows: automated lead qualification, document processing, and tenant communication systems.</p>
                </div>
                <div class="card">
                    <h4>Loma Autos</h4>
                    <p>AI reception and lead handling: intelligent call routing, automated appointment booking, and support ticket classification.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="section">
        <div class="container-narrow text-center">
            <h2 class="mb-md">Ready to Start?</h2>
            <p class="mb-xl">Take the AI Readiness Scorecard to understand where you are, or book a free 20-minute discovery call to discuss your specific challenges.</p>
            <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                <a href="/assessment/" class="btn btn-primary btn-lg">Take Scorecard</a>
                <a href="/book/" class="btn btn-secondary btn-lg">Book Call</a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h4>AiGentForce.io</h4>
                    <p>Executive AI Strategy, Training & Automation</p>
                </div>
                <div class="footer-section">
                    <h4>Services</h4>
                    <a href="/workshops/">Workshops</a>
                    <a href="/assessment/">AI Readiness</a>
                    <a href="/resources/">Resources</a>
                </div>
                <div class="footer-section">
                    <h4>Company</h4>
                    <a href="/about/">About</a>
                    <a href="/privacy/">Privacy</a>
                    <a href="/terms/">Terms</a>
                </div>
                <div class="footer-section">
                    <h4>Contact</h4>
                    <a href="/book/">Book Call</a>
                    <a href="mailto:info@aigentforce.io">info@aigentforce.io</a>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 AiGentForce.io. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Chatwoot Widget -->
    <script>
        window.chatwootSettings = {
            hideMessageBubble: false,
            position: 'right',
            locale: 'en',
            type: 'standard'
        };
        (function(d,t) {
            var BASE_URL="https://app.chatwoot.com";
            var g=d.createElement(t),s=d.getElementsByTagName(t)[0];
            g.src=BASE_URL+"/packs/js/sdk.js";
            g.defer = true;
            g.async = true;
            s.parentNode.insertBefore(g,s);
            g.onload=function(){
                window.chatwootSDK.run({
                    websiteToken: 'YOUR_CHATWOOT_WEBSITE_TOKEN',
                    baseUrl: BASE_URL
                });
            }
        })(document,"script");
    </script>

    <script src="/assets/js/main.js"></script>
</body>
</html>
