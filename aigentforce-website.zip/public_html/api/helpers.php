<?php
// api/helpers.php
// Shared helper functions

require_once __DIR__ . '/config.php';

/**
 * Log message to file
 */
function log_message($message, $level = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[{$timestamp}] [{$level}] {$message}" . PHP_EOL;
    file_put_contents(LOG_FILE, $log_entry, FILE_APPEND);
}

/**
 * Send JSON response
 */
function json_response($data, $status_code = 200) {
    http_response_code($status_code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/**
 * Validate CSRF token
 */
function validate_csrf($token) {
    if (empty($token)) {
        return false;
    }
    // Simple validation - in production, use session-based tokens
    $expected = hash_hmac('sha256', 'csrf_token', CSRF_TOKEN_SECRET);
    return hash_equals($expected, $token);
}

/**
 * Generate CSRF token
 */
function generate_csrf_token() {
    return hash_hmac('sha256', 'csrf_token', CSRF_TOKEN_SECRET);
}

/**
 * Forward data to automation webhook (Google Sheets)
 */
function forward_to_automation($payload) {
    $ch = curl_init(AUTOMATION_WEBHOOK_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        log_message("Webhook error: {$error}", 'ERROR');
        return false;
    }

    if ($http_code !== 200) {
        log_message("Webhook returned HTTP {$http_code}: {$response}", 'WARNING');
        return false;
    }

    log_message("Webhook success: {$response}");
    return true;
}

/**
 * Send email via SMTP
 * Note: For production, use PHPMailer library for better reliability
 */
function send_email($to, $subject, $body, $is_html = true) {
    $headers = [
        'From: ' . SMTP_FROM_NAME . ' <' . SMTP_FROM_EMAIL . '>',
        'Reply-To: ' . SMTP_FROM_EMAIL,
        'X-Mailer: PHP/' . phpversion()
    ];

    if ($is_html) {
        $headers[] = 'MIME-Version: 1.0';
        $headers[] = 'Content-type: text/html; charset=UTF-8';
    }

    $success = mail($to, $subject, $body, implode("\r\n", $headers));

    if ($success) {
        log_message("Email sent to {$to}: {$subject}");
    } else {
        log_message("Email failed to {$to}: {$subject}", 'ERROR');
    }

    return $success;
}

/**
 * Sanitize input
 */
function sanitize_input($data) {
    if (is_array($data)) {
        return array_map('sanitize_input', $data);
    }
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

/**
 * Validate email
 */
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}
