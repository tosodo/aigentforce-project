<?php
// api/assessment.php
// Handle AI readiness assessment submissions

require_once __DIR__ . '/helpers.php';

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    json_response(['error' => 'Invalid JSON'], 400);
}

// Validate CSRF token
if (!validate_csrf($input['csrf_token'] ?? '')) {
    log_message('CSRF validation failed', 'WARNING');
    json_response(['error' => 'Invalid security token'], 403);
}

// Sanitize inputs
$data = sanitize_input($input);

// Validate required fields
if (empty($data['email']) || !validate_email($data['email'])) {
    json_response(['error' => 'Valid email is required'], 400);
}

if (empty($data['assessment'])) {
    json_response(['error' => 'Assessment data is required'], 400);
}

// Build assessment payload
$assessment_payload = [
    'type' => 'assessment',
    'lead' => [
        'name' => $data['name'] ?? '',
        'email' => $data['email'],
        'company' => $data['company'] ?? '',
        'role' => $data['role'] ?? '',
        'team_size' => $data['team_size'] ?? '',
        'source' => 'assessment',
        'timestamp' => date('c')
    ],
    'assessment' => $data['assessment']
];

// Forward to automation webhook
$webhook_success = forward_to_automation($assessment_payload);

// Send results email to lead
$total_score = $data['assessment']['total_score'] ?? 0;
$risk_level = $data['assessment']['risk_level'] ?? 'unknown';
$recommendations = $data['assessment']['recommendations'] ?? [];
$suggested_cta = $data['assessment']['suggested_cta'] ?? '';

$recommendations_html = '';
foreach ($recommendations as $rec) {
    $recommendations_html .= "<li>{$rec}</li>";
}

$email_subject = 'Your AI Readiness Assessment Results';
$email_body = "
    <h2>Your AI Readiness Score: {$total_score}/100</h2>
    <p><strong>Risk Level:</strong> " . ucfirst($risk_level) . "</p>

    <h3>Pillar Scores:</h3>
    <ul>
        <li>Data readiness: {$data['assessment']['pillar_scores']['Data readiness']}/20</li>
        <li>Process clarity: {$data['assessment']['pillar_scores']['Process clarity']}/20</li>
        <li>People & roles: {$data['assessment']['pillar_scores']['People & roles']}/20</li>
        <li>Infrastructure & tooling: {$data['assessment']['pillar_scores']['Infrastructure & tooling']}/20</li>
        <li>Governance & risk: {$data['assessment']['pillar_scores']['Governance & risk']}/20</li>
    </ul>

    <h3>Recommendations:</h3>
    <ul>{$recommendations_html}</ul>

    <h3>Next Steps:</h3>
    <p>{$suggested_cta}</p>

    <p><a href='" . BASE_URL . "/workshops/'>View our workshops</a> | <a href='" . BASE_URL . "/book/'>Book a discovery call</a></p>

    <p>Best regards,<br>AiGentForce.io Team</p>
";

send_email($data['email'], $email_subject, $email_body, true);

// Send internal notification
$internal_subject = "New Assessment: {$total_score}/100 ({$risk_level})";
$internal_body = "
    <h3>New Assessment Completed</h3>
    <p><strong>Name:</strong> {$data['name']}</p>
    <p><strong>Email:</strong> {$data['email']}</p>
    <p><strong>Company:</strong> {$data['company']}</p>
    <p><strong>Score:</strong> {$total_score}/100</p>
    <p><strong>Risk Level:</strong> {$risk_level}</p>
    <p><strong>Webhook Status:</strong> " . ($webhook_success ? 'Success' : 'Failed') . "</p>
";
send_email(ESCALATION_EMAIL, $internal_subject, $internal_body, true);

// Return success
json_response(['success' => true]);
