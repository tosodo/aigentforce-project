<?php
// api/config.example.php
// Copy this file to config.php and fill in your actual values

// BRAND
define('BRAND_NAME', 'AiGentForce.io');

// ENVIRONMENT
define('ENVIRONMENT', 'production'); // or 'development'

// BASE URL (no trailing slash)
define('BASE_URL', 'https://aigentforce.io');

// GOOGLE SHEETS / AUTOMATION WEBHOOK
// Deploy the Google Apps Script as a Web App and paste the URL here
define('AUTOMATION_WEBHOOK_URL', 'https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec');

// CHATWOOT
define('CHATWOOT_BASE_URL', 'https://app.chatwoot.com');
define('CHATWOOT_WEBSITE_TOKEN', 'YOUR_CHATWOOT_WEBSITE_TOKEN_HERE');
define('CHATWOOT_API_ACCESS_TOKEN', 'YOUR_CHATWOOT_API_ACCESS_TOKEN_HERE');

// EMAIL / SMTP
define('SMTP_HOST', 'mail.yourdomain.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'no-reply@aigentforce.io');
define('SMTP_PASSWORD', 'YOUR_SECURE_PASSWORD_HERE');
define('SMTP_FROM_EMAIL', 'no-reply@aigentforce.io');
define('SMTP_FROM_NAME', 'AiGentForce.io');
define('ESCALATION_EMAIL', 'info@aigentforce.io');

// GOOGLE CALENDAR APPOINTMENT SCHEDULE
// Create an appointment schedule and paste the public booking URL here
define('G_CAL_APPOINTMENT_URL', 'https://calendar.google.com/calendar/appointments/schedules/YOUR_SCHEDULE_ID');

// SECURITY
// Generate a random 32+ character string for CSRF protection
define('CSRF_TOKEN_SECRET', 'CHANGE_THIS_TO_A_SECURE_RANDOM_STRING_32_CHARS_MIN');

// LOGGING
define('LOG_FILE', __DIR__ . '/logs/app.log');
