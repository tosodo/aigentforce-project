<?php
// api/lead.php
// Handle lead submissions from various forms

require_once __DIR__ . '/helpers.php';

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    json_response(['error' => 'Invalid JSON'], 400);
}

// Validate CSRF token
if (!validate_csrf($input['csrf_token'] ?? '')) {
    log_message('CSRF validation failed', 'WARNING');
    json_response(['error' => 'Invalid security token'], 403);
}

// Sanitize inputs
$data = sanitize_input($input);

// Validate required fields
if (empty($data['email']) || !validate_email($data['email'])) {
    json_response(['error' => 'Valid email is required'], 400);
}

// Determine lead type and source
$type = $data['type'] ?? 'general';
$source = $data['source'] ?? 'unknown';

// Build lead payload
$lead_payload = [
    'type' => $type,
    'lead' => [
        'name' => $data['name'] ?? '',
        'email' => $data['email'],
        'phone' => $data['phone'] ?? '',
        'company' => $data['company'] ?? '',
        'role' => $data['role'] ?? '',
        'team_size' => $data['team_size'] ?? '',
        'goal' => $data['goal'] ?? '',
        'timeline' => $data['timeline'] ?? '',
        'offer' => $data['offer'] ?? '',
        'source' => $source,
        'timestamp' => date('c')
    ]
];

// Forward to automation webhook
$webhook_success = forward_to_automation($lead_payload);

// Send confirmation email to lead
$email_subject = '';
$email_body = '';

switch ($type) {
    case 'workshop_enquiry':
        $email_subject = 'Your AiGentForce.io Workshop Enquiry';
        $email_body = "
            <p>Hi {$data['name']},</p>
            <p>Thank you for your interest in our AI training workshops.</p>
            <p>We've received your enquiry and will respond within 24 hours with tailored recommendations based on your team size and goals.</p>
            <p>In the meantime, you can:</p>
            <ul>
                <li><a href='" . BASE_URL . "/assessment/'>Complete our AI Readiness Scorecard</a></li>
                <li><a href='" . BASE_URL . "/resources/'>Download our Executive AI Playbook</a></li>
            </ul>
            <p>Best regards,<br>AiGentForce.io Team</p>
        ";
        break;

    case 'playbook_download':
        $email_subject = 'Your Executive AI Playbook';
        $email_body = "
            <p>Hi {$data['name']},</p>
            <p>Thank you for downloading the Executive AI Playbook.</p>
            <p><strong><a href='" . BASE_URL . "/assets/files/executive-ai-playbook.pdf'>Download your playbook here</a></strong></p>
            <p>This guide covers:</p>
            <ul>
                <li>AI readiness assessment framework</li>
                <li>Practical implementation roadmap</li>
                <li>Risk management strategies</li>
                <li>ROI measurement approaches</li>
            </ul>
            <p>Next steps:</p>
            <ul>
                <li><a href='" . BASE_URL . "/assessment/'>Take the AI Readiness Scorecard</a></li>
                <li><a href='" . BASE_URL . "/book/'>Book a free 20-minute discovery call</a></li>
            </ul>
            <p>Best regards,<br>AiGentForce.io Team</p>
        ";
        break;

    case 'book_call':
        $email_subject = 'Your Discovery Call Booking';
        $email_body = "
            <p>Hi {$data['name']},</p>
            <p>Thank you for your interest in a discovery call.</p>
            <p><strong><a href='" . G_CAL_APPOINTMENT_URL . "'>Click here to select your preferred time</a></strong></p>
            <p>During the call, we'll discuss:</p>
            <ul>
                <li>Your current AI readiness and challenges</li>
                <li>Practical opportunities for AI in your operations</li>
                <li>Recommended next steps and timeline</li>
            </ul>
            <p>Best regards,<br>AiGentForce.io Team</p>
        ";
        break;

    default:
        $email_subject = 'Thank you for contacting AiGentForce.io';
        $email_body = "
            <p>Hi {$data['name']},</p>
            <p>Thank you for getting in touch. We've received your message and will respond within 24 hours.</p>
            <p>Best regards,<br>AiGentForce.io Team</p>
        ";
}

// Send email
send_email($data['email'], $email_subject, $email_body, true);

// Send internal notification
$internal_subject = "New Lead: {$type}";
$internal_body = "
    <h3>New Lead Received</h3>
    <p><strong>Type:</strong> {$type}</p>
    <p><strong>Source:</strong> {$source}</p>
    <p><strong>Name:</strong> {$data['name']}</p>
    <p><strong>Email:</strong> {$data['email']}</p>
    <p><strong>Company:</strong> {$data['company']}</p>
    <p><strong>Goal:</strong> {$data['goal']}</p>
    <p><strong>Webhook Status:</strong> " . ($webhook_success ? 'Success' : 'Failed') . "</p>
";
send_email(ESCALATION_EMAIL, $internal_subject, $internal_body, true);

// Return success
json_response(['success' => true]);
