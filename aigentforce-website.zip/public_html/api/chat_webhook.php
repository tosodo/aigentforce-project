<?php
// api/chat_webhook.php
// Handle Chatwoot webhook for automated intent classification and replies

require_once __DIR__ . '/helpers.php';

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    json_response(['error' => 'Invalid JSON'], 400);
}

// Only process incoming messages
if ($input['message_type'] !== 'incoming') {
    json_response(['success' => true, 'action' => 'ignored_outgoing']);
}

$message_content = strtolower($input['content'] ?? '');
$conversation_id = $input['conversation']['id'] ?? null;
$sender_name = $input['sender']['name'] ?? 'there';

if (!$conversation_id) {
    json_response(['error' => 'No conversation ID'], 400);
}

// Classify intent based on keywords
$intent = 'general';
$escalate = false;

// Training intent
if (preg_match('/\b(train|training|workshop|course|learn|upskill)\b/i', $message_content)) {
    $intent = 'training';
}

// Private workshop intent
if (preg_match('/\b(private|onsite|in-house|company|team workshop)\b/i', $message_content)) {
    $intent = 'private_workshop';
    $escalate = true;
}

// Assessment intent
if (preg_match('/\b(assessment|scorecard|readiness|evaluate|benchmark)\b/i', $message_content)) {
    $intent = 'assessment';
}

// Automation intent
if (preg_match('/\b(automat|workflow|process|integration|system)\b/i', $message_content)) {
    $intent = 'automation';
    $escalate = true;
}

// Enterprise keywords trigger escalation
if (preg_match('/\b(budget|board|enterprise|contract|legal|compliance)\b/i', $message_content)) {
    $escalate = true;
}

// Generate auto-reply based on intent
$reply_text = '';

switch ($intent) {
    case 'training':
        $reply_text = "Thanks for getting in touch. We design focused AI training and workshops for leadership teams and operators. If you share your team size and primary outcome, we can recommend a public session, a team pass, or a private workshop.";
        break;

    case 'private_workshop':
        $reply_text = "We deliver private, onsite workshops tailored to your organisation's workflows and challenges. These typically run as half-day or full-day sessions for leadership and operational teams. A member of our team will reach out shortly to discuss your requirements.";
        break;

    case 'assessment':
        $reply_text = "Our AI Readiness Scorecard benchmarks your organisation across data, process, people, infrastructure, and governance. You can complete it in under 10 minutes on the site, and we'll provide a clear, written set of next steps.";
        break;

    case 'automation':
        $reply_text = "We help organisations design and implement AI-driven workflow automation—from lead handling and document processing to customer support and operations. A team member will follow up to understand your specific use case.";
        break;

    default:
        $reply_text = "Thanks for reaching out. How can we help? We offer AI training workshops, readiness assessments, and automation implementation for SMEs and service businesses.";
}

// Send auto-reply via Chatwoot API
$chatwoot_url = CHATWOOT_BASE_URL . "/api/v1/accounts/" . getenv('CHATWOOT_ACCOUNT_ID') . "/conversations/{$conversation_id}/messages";

$reply_payload = [
    'content' => $reply_text,
    'message_type' => 'outgoing',
    'private' => false
];

$ch = curl_init($chatwoot_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($reply_payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'api_access_token: ' . CHATWOOT_API_ACCESS_TOKEN
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http_code !== 200) {
    log_message("Chatwoot API error: HTTP {$http_code} - {$response}", 'ERROR');
}

// Escalate to human if needed
if ($escalate) {
    $escalation_subject = "Chat Escalation: {$intent}";
    $escalation_body = "
        <h3>Chat Conversation Requires Human Response</h3>
        <p><strong>Intent:</strong> {$intent}</p>
        <p><strong>Sender:</strong> {$sender_name}</p>
        <p><strong>Message:</strong> {$input['content']}</p>
        <p><strong>Conversation ID:</strong> {$conversation_id}</p>
        <p><a href='" . CHATWOOT_BASE_URL . "/app/accounts/1/conversations/{$conversation_id}'>View in Chatwoot</a></p>
    ";
    send_email(ESCALATION_EMAIL, $escalation_subject, $escalation_body, true);
    log_message("Chat escalated: {$intent} - Conversation {$conversation_id}");
}

json_response(['success' => true, 'intent' => $intent, 'escalated' => $escalate]);
