# Deployment Guide - AiGentForce.io

## Quick Start

1. **Configure**: Copy `public_html/api/config.example.php` to `config.php` and fill in your credentials
2. **Package**: ZIP the `public_html` directory contents
3. **Upload**: Upload to cPanel File Manager
4. **Extract**: Extract in `public_html` directory
5. **Test**: Visit your domain

## Detailed Steps

### 1. Configuration
Edit `public_html/api/config.php`:
- BASE_URL: Your domain
- AUTOMATION_WEBHOOK_URL: Google Apps Script URL
- CHATWOOT tokens
- SMTP credentials
- Google Calendar URL
- CSRF secret (32+ random characters)

### 2. Google Sheets Setup
See `docs/GOOGLE_SHEETS_SETUP.md`

### 3. Chatwoot Setup
See `docs/CHATWOOT_INTEGRATION.md`

### 4. Upload to cPanel
- Log into cPanel
- File Manager -> public_html
- Upload ZIP and extract
- Set permissions: `api/logs/` to 755

### 5. Enable SSL
- cPanel -> SSL/TLS Status
- Enable AutoSSL

### 6. Test
- Visit your domain
- Test all forms
- Check email delivery
- Verify Google Sheets integration

## Troubleshooting
- Check `api/logs/app.log` for errors
- Verify SMTP credentials
- Test webhook URL
- Check browser console for JavaScript errors

For full documentation, see README.md and docs/ directory.
