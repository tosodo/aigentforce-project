# Chatwoot Integration

## 1. Create Account
Sign up at chatwoot.com or self-host

## 2. Create Website Inbox
- Settings -> Inboxes -> Add Inbox -> Website
- Copy Website Token
- Add to `config.php` as `CHATWOOT_WEBSITE_TOKEN`

## 3. Generate API Token
- Profile Settings -> Access Token
- Copy token
- Add to `config.php` as `CHATWOOT_API_ACCESS_TOKEN`

## 4. Configure Webhook
- Settings -> Integrations -> Webhooks
- URL: `https://yourdomain.com/api/chat_webhook.php`
- Events: `message_created`

## 5. Test
- Visit website
- Open chat widget
- Send test message
- Verify auto-reply

See full documentation in project README.
