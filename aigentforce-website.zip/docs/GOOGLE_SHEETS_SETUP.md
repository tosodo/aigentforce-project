# Google Sheets CRM Setup

## 1. Create Spreadsheet
- Name: "AiGentForce CRM"
- Create two sheets: `leads` and `assessments`

## 2. Leads Sheet Headers
name | email | phone | company | role | team_size | goal | timeline | offer | source | timestamp

## 3. Assessments Sheet Headers
lead_email | lead_name | company | role | team_size | answers_json | total_score | pillar_scores_json | risk_level | recommendations | suggested_cta | timestamp

## 4. Deploy Google Apps Script
- Extensions -> Apps Script
- Paste code from `/scripts/google-apps-script.js`
- Deploy -> New deployment -> Web app
- Execute as: Me
- Who has access: Anyone
- Copy Web app URL

## 5. Update Config
Add Web app URL to `config.php` as `AUTOMATION_WEBHOOK_URL`

See full documentation in project README.
