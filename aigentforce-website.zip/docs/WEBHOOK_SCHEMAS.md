# Webhook Payload Schemas

## Lead Webhook
{
  "type": "workshop_enquiry",
  "lead": {
    "name": "John Smith",
    "email": "john@example.com",
    "company": "Acme Ltd",
    "source": "workshops_page",
    "timestamp": "2026-01-16T10:00:00Z"
  }
}

## Assessment Webhook
{
  "type": "assessment",
  "lead": {
    "email": "john@example.com",
    "name": "John Smith"
  },
  "assessment": {
    "total_score": 72,
    "pillar_scores": {},
    "risk_level": "low",
    "recommendations": []
  }
}

See full schemas in project documentation.
