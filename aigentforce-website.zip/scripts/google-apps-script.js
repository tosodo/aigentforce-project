// Google Apps Script for AiGentForce.io webhook receiver

function doPost(e) {
  try {
    const payload = JSON.parse(e.postData.contents);
    const type = payload.type;

    if (type === 'assessment') {
      handleAssessment(payload);
    } else {
      handleLead(payload);
    }

    return ContentService.createTextOutput(JSON.stringify({success: true}))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    Logger.log('Error: ' + error.toString());
    return ContentService.createTextOutput(JSON.stringify({error: error.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function handleLead(payload) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('leads');
  const lead = payload.lead;

  sheet.appendRow([
    lead.name || '',
    lead.email || '',
    lead.phone || '',
    lead.company || '',
    lead.role || '',
    lead.team_size || '',
    lead.goal || '',
    lead.timeline || '',
    lead.offer || '',
    lead.source || '',
    lead.timestamp || new Date().toISOString()
  ]);
}

function handleAssessment(payload) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('assessments');
  const lead = payload.lead;
  const assessment = payload.assessment;

  sheet.appendRow([
    lead.email || '',
    lead.name || '',
    lead.company || '',
    lead.role || '',
    lead.team_size || '',
    JSON.stringify(assessment.answers || {}),
    assessment.total_score || 0,
    JSON.stringify(assessment.pillar_scores || {}),
    assessment.risk_level || '',
    JSON.stringify(assessment.recommendations || []),
    assessment.suggested_cta || '',
    lead.timestamp || new Date().toISOString()
  ]);
}
