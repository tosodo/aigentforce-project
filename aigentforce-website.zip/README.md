# AiGentForce.io Website

Executive-grade AI strategy, training and automation platform for SMEs, local service businesses, and agencies.

## Overview

This is a production-ready, mobile-first website built for Namecheap shared hosting with cPanel. The platform enables:

- **AI Training & Workshops** (public, team, and private sessions)
- **AI Readiness Scorecard** (5-pillar assessment with automated scoring)
- **Discovery Call Booking** (Google Calendar integration)
- **Lead Management** (Google Sheets CRM via webhooks)
- **Chat Support** (Chatwoot widget with automated intent classification)

## Tech Stack

- **Frontend**: Static HTML/CSS/JS with utility-first styling
- **Backend**: Lightweight PHP endpoints (cPanel-compatible)
- **CRM**: Google Sheets via webhook automation
- **Email**: SMTP (Namecheap/Gmail/SendGrid)
- **Chat**: Chatwoot widget + webhook handler
- **Booking**: Google Calendar Appointment Schedules

## Key Features

- McKinsey-level minimalist design
- Mobile-first responsive layout
- Executive tone (no AI hype)
- 5-pillar AI readiness assessment with automated scoring
- Webhook-based integrations (no always-on workers)
- CSRF protection
- Graceful degradation for static-only fallback

## Brand Guidelines

**Colour Palette:**
- Deep Tech Blue: #0A1A2F
- Carbon Graphite: #1A1A1A
- Electric Cyan: #00E0FF
- Scientific Green: #00C27A
- Clean White: #FFFFFF
- Soft Grey: #E6E6E6

**Typography:** Inter or Manrope (system fallback)

## Quick Start

### 1. Extract the ZIP file

Extract all contents to your local machine.

### 2. Configure environment

Copy the example config:
```bash
cp public_html/api/config.example.php public_html/api/config.php
```

Edit config.php with your credentials:
- Base URL
- Automation webhook URL (Google Apps Script)
- Chatwoot tokens
- SMTP credentials
- Google Calendar appointment URL
- CSRF secret

### 3. Deploy to Namecheap

See DEPLOYMENT.md for detailed instructions.

## Documentation

- [Deployment Guide](DEPLOYMENT.md)
- [Google Sheets Setup](docs/GOOGLE_SHEETS_SETUP.md)
- [Chatwoot Integration](docs/CHATWOOT_INTEGRATION.md)
- [Webhook Schemas](docs/WEBHOOK_SCHEMAS.md)

## Project Structure

```
public_html/          # Web root (upload to cPanel)
├── index.php         # Home page
├── workshops/        # Training & pricing
├── assessment/       # AI readiness scorecard
├── book/            # Discovery call booking
├── resources/       # Playbook & resources
├── about/           # About page
├── privacy/         # Privacy policy
├── terms/           # Terms of service
├── assets/          # CSS, JS, files
└── api/             # PHP endpoints
```

## API Endpoints

- POST /api/lead.php - Lead capture (forms, playbook, booking)
- POST /api/assessment.php - Assessment submission & scoring
- POST /api/chat_webhook.php - Chatwoot webhook handler

## Security

- CSRF token validation on all forms
- Input sanitization and validation
- HTTPS enforced (AutoSSL)
- Secure SMTP credentials
- Webhook signature verification (recommended)

## License

Proprietary - All rights reserved by AiGentForce.io

## Support

For technical issues or questions:
- Email: info@aigentforce.io
- Documentation: See /docs directory

## Next Steps

1. Configure config.php with your credentials
2. Set up Google Sheets (see docs/GOOGLE_SHEETS_SETUP.md)
3. Configure Chatwoot (see docs/CHATWOOT_INTEGRATION.md)
4. Deploy to cPanel (see DEPLOYMENT.md)
5. Test all forms and integrations

## Important Notes

- This is a starter template - you'll need to create the remaining pages (workshops, assessment, book, resources, about, privacy, terms)
- The assessment.js contains the full 20-question assessment logic
- All API endpoints are production-ready
- Email functionality requires valid SMTP credentials
- Google Sheets integration requires deploying the Apps Script

## File Checklist

Core files included:
- ✓ Configuration (config.example.php)
- ✓ API endpoints (lead.php, assessment.php, chat_webhook.php)
- ✓ Helper functions (helpers.php)
- ✓ CSS styles (styles.css)
- ✓ JavaScript (main.js, assessment.js)
- ✓ Homepage (index.php)
- ✓ Documentation (README, DEPLOYMENT, setup guides)
- ✓ Google Apps Script
- ✓ .htaccess, robots.txt, sitemap.xml

Pages to create:
- workshops/index.php
- assessment/index.php
- assessment/results.html
- book/index.php
- resources/index.php
- about/index.php
- privacy/index.php
- terms/index.php

You can use the homepage (index.php) as a template for creating these pages.
